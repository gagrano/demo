package com.iseecars.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.iseecars.demo.repo.StateCapitalRepository;

@SpringBootTest
class IseecarsApplicationTests {

	@Autowired
    private StateCapitalRepository repository;
	
	@Test
	void contextLoads() {
	}

	@Test
	public void whenFindByState_returnCityOrEmpty() {
		Assertions.assertEquals(repository.count(), 50);
		
		Assertions.assertEquals(repository.findByState("MA").get(0).getCity(), "Boston");
		
		Assertions.assertTrue(repository.findByState("AA").isEmpty());
	}
}
