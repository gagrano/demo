-- Create in Postgresql schema iseecars for user: postgres and password: nemwa1
CREATE TABLE state_capitals
(
    id smallint NOT NULL,
    state character varying(2) NOT NULL,
    city character varying(50) NOT NULL,
    CONSTRAINT state_capitals_pkey PRIMARY KEY (id),
    CONSTRAINT unique_state UNIQUE (state)
);