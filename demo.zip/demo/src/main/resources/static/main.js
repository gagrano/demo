$(document).ready(function () {
    $("#state").val("");
    var lookupArr = [];
    console.log("lookups before search : "+ lookupArr);
    $("#search-form").submit(function (event) {
        event.preventDefault();
        if (lookupArr.length > 0) {
        	var now = Date.now();
        	var diff = parseInt((now - lookupArr[0])/ 1000);
        	if (lookupArr.length == 1) {     	 
        	    if (diff > 30) lookupArr.shift();
        	    lookupArr.push(now);
        	    fire_ajax_search();
        	} else {
        		if (diff > 30) {
        		    console.log("diff = "+ diff + " sec - removing 1st");
        			lookupArr.shift();
        			console.log("lookups after removal 1st : "+ lookupArr);
        			diff = parseInt((now - lookupArr[0])/ 1000);
        			if (diff > 30) lookupArr.shift();		
        			lookupArr.push(now);
        			fire_ajax_search();
        		} else {
        			$('#state_capital').html("Too many requests. Wait for "+ (30 - diff) + " seconds");
        		}
        	}
        } else {
        	lookupArr.push(Date.now());
        	fire_ajax_search();
        }
        console.log("lookups after search : "+ lookupArr);
    });
    
	$("#state").bind('keyup', function (e) {
	    if (e.which >= 97 && e.which <= 122) {
	        var newKey = e.which - 32;
	        e.keyCode = newKey;
	        e.charCode = newKey;
	    }	
	    $("#state").val(($("#state").val()).toUpperCase());
	});
});

function fire_ajax_search() {
    $("#btn-search").prop("disabled", true);

    $.ajax({
        type: "GET",
        url: "/getCityByState",
        data: { state: $("#state").val() },
        cache: false,
        success: function (data) {
            $('#state_capital').html(data);

            console.log("SUCCESS : ", data);
            $("#btn-search").prop("disabled", false);
            $("#state").val("");
        },
        error: function (e) {
            var json = e.responseText;
            $('#feedback').html(json);

            console.log("ERROR : ", e);
            $("#btn-search").prop("disabled", false);
        }
    });
}