package com.iseecars.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IseecarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IseecarsApplication.class, args);
	}

}
