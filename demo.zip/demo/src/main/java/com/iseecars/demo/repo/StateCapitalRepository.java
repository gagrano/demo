package com.iseecars.demo.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.iseecars.demo.entity.StateCapital;

@Repository
public interface StateCapitalRepository extends CrudRepository<StateCapital, Long> {
	/**
	 * actually looks-up in the db table the capital by state
	 * @param state
	 * @return
	 */
	public List<StateCapital> findByState(String state);
}
