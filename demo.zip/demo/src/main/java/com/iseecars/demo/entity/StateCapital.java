/**
 * 
 */
package com.iseecars.demo.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author User
 *
 */
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="state_capitals")
public class StateCapital implements Serializable {
	public final static long serialVersionUID = 1l;
	
	@Id
	@SequenceGenerator(name = "state_generator", sequenceName= "state_sequence", initialValue=1)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name="STATE", length=2, nullable=false, unique=true)
	private String state;
	
	@Column(name="CITY", length=50, nullable=false, unique=false)
	private String city; 
}
