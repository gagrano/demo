/**
 * 
 */
package com.iseecars.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iseecars.demo.entity.StateCapital;
import com.iseecars.demo.repo.StateCapitalRepository;

/**
 * @author gennady
 *
 */
@RestController
public class CityController {
	@Autowired
	StateCapitalRepository repository;
	
	/**
	 * populates state capitals in database only once
	 * @return
	 */
	@RequestMapping("/populate")
	public String populate() {
		if (repository.count() == 0) {
			repository.save(StateCapital.builder().state("AL").city("Montgomery").build());
			repository.save(StateCapital.builder().state("AK").city("Juneau").build());
			repository.save(StateCapital.builder().state("AZ").city("Phoenix").build());
			repository.save(StateCapital.builder().state("AR").city("Little Rock").build());
			repository.save(StateCapital.builder().state("CA").city("Sacramento").build());
			repository.save(StateCapital.builder().state("CO").city("Denver").build());
			repository.save(StateCapital.builder().state("CT").city("Hartford").build());
			repository.save(StateCapital.builder().state("DE").city("Dover").build());
			repository.save(StateCapital.builder().state("FL").city("Tallahassee").build());
			repository.save(StateCapital.builder().state("GA").city("Atlanta").build());
			repository.save(StateCapital.builder().state("HI").city("Honolulu").build());
			repository.save(StateCapital.builder().state("ID").city("Boise").build());
			repository.save(StateCapital.builder().state("IL").city("Springfield").build());
			repository.save(StateCapital.builder().state("IN").city("Indianapolis").build());
			repository.save(StateCapital.builder().state("IA").city("Des Moines").build());
			repository.save(StateCapital.builder().state("KS").city("Topeka").build());
			repository.save(StateCapital.builder().state("KY").city("Frankfort").build());
			repository.save(StateCapital.builder().state("LA").city("Baton Rouge").build());
			repository.save(StateCapital.builder().state("ME").city("Augusta").build());
			repository.save(StateCapital.builder().state("MD").city("Annapolis").build());
			repository.save(StateCapital.builder().state("MA").city("Boston").build());
			repository.save(StateCapital.builder().state("MI").city("Lansing").build());
			repository.save(StateCapital.builder().state("MN").city("St. Paul").build());
			repository.save(StateCapital.builder().state("MS").city("Jackson").build());
			repository.save(StateCapital.builder().state("MO").city("Jefferson City").build());
			repository.save(StateCapital.builder().state("MT").city("Helena").build());
			repository.save(StateCapital.builder().state("NE").city("Lincoln").build());
			repository.save(StateCapital.builder().state("NV").city("Carson City").build());
			repository.save(StateCapital.builder().state("NH").city("Concord").build());
			repository.save(StateCapital.builder().state("NJ").city("Trenton").build());
			repository.save(StateCapital.builder().state("NM").city("Santa Fe").build());
			repository.save(StateCapital.builder().state("NY").city("Albany").build());
			repository.save(StateCapital.builder().state("NC").city("Raleigh").build());
			repository.save(StateCapital.builder().state("ND").city("Bismarck").build());
			repository.save(StateCapital.builder().state("OH").city("Columbus").build());
			repository.save(StateCapital.builder().state("OK").city("Oklahoma City").build());
			repository.save(StateCapital.builder().state("OR").city("Salem").build());
			repository.save(StateCapital.builder().state("PA").city("Harrisburg").build());
			repository.save(StateCapital.builder().state("RI").city("Providence").build());
			repository.save(StateCapital.builder().state("SC").city("Columbia").build());
			repository.save(StateCapital.builder().state("SD").city("Pierre").build());
			repository.save(StateCapital.builder().state("TN").city("Nashville").build());
			repository.save(StateCapital.builder().state("TX").city("Austin").build());
			repository.save(StateCapital.builder().state("UT").city("Salt Lake City").build());
			repository.save(StateCapital.builder().state("VT").city("Montpelier").build());
			repository.save(StateCapital.builder().state("VA").city("Richmond").build());
			repository.save(StateCapital.builder().state("WA").city("Olympia").build());
			repository.save(StateCapital.builder().state("WV").city("Charleston").build());
			repository.save(StateCapital.builder().state("WI").city("Madison").build());
			repository.save(StateCapital.builder().state("WY").city("Cheyenne").build());
			return "Done!";
		} else {
			return "Already populated!";
		}
	}
	
	/**
	 * Gets a Capital City By State
	 * @param state
	 * @return String - capital city
	 */
	@RequestMapping("/getCityByState")
	public String getCityByState(@RequestParam("state") String state) {
		List<StateCapital> scList = repository.findByState(state);
		int count = scList.size();
		switch(count) {
			case 1: return scList.get(0).getCity(); 
			case 0: return "Incorrect State Code:)";
			default: return "Weird Case";
		}
	}
}
