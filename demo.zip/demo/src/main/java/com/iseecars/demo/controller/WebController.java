/**
 * 
 */
package com.iseecars.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author gennady
 *
 */
@Controller
public class WebController {
	@RequestMapping("/")
	public String index() {
		return "index";
	}
}
